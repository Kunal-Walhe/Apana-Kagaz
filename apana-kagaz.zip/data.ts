import { Poetry } from './types';

export const initialPoetryData: Poetry[] = [
  { "id": 1, "poet": "Ahmad Faraz", "type": "ghazal", "text": "Aankh se door na ho dil se utar jayega\nWaqt ka kya hai guzarta hai guzar jayega" },
  { "id": 2, "poet": "Mirza Ghalib", "type": "shayari", "text": "Ishq ne 'Ghalib' nikamma kar diya\nWarna hum bhi aadmi the kaam ke" },
  { "id": 3, "poet": "Allama Iqbal", "type": "shayari", "text": "Khudi ko kar buland itna ki har taqdeer se pehle\nKhuda bande se khud pooche bata teri raza kya hai" },
  { "id": 4, "poet": "Mir Taqi Mir", "type": "shayari", "text": "Patta patta boota boota haal hamara jaane hai\nJaane na jaane gul hi na jaane bagh toh sara jaane hai" },
  { "id": 5, "poet": "Faiz Ahmad Faiz", "type": "ghazal", "text": "Gulon mein rang bhare baad-e-nau-bahar chale\nChale bhi aao ki gulshan ka karobar chale" },
  { "id": 6, "poet": "Jaun Elia", "type": "shayari", "text": "Jo guzari na ja saki hum se\nHum ne wo zindagi guzari hai" },
  { "id": 7, "poet": "Rahat Indori", "type": "shayari", "text": "Sabhi ka khoon hai shamil yahan ki mitti mein\nKisi ke baap ka Hindustan thodi hai" },
  { "id": 8, "poet": "Gulzar", "type": "shayari", "text": "Duniya mein rehne ki do hi jagah acchi hain\nKisi ke dil mein ya kisi ki duaon mein" },
  { "id": 9, "poet": "Munawwar Rana", "type": "shayari", "text": "Kisi ko ghar mila hisse mein ya koi dukan aayi\nMain ghar mein sab se chhota tha mere hisse mein Maa aayi" },
  { "id": 10, "poet": "Nida Fazli", "type": "shayari", "text": "Duniya jise kehte hain jadoo ka khilona hai\nMil gaya toh mitti hai kho gaya toh sona hai" },
  { "id": 11, "poet": "Sahir Ludhianvi", "type": "shayari", "text": "Main pal do pal ka shayer hoon\nPal do pal meri kahani hai" },
  { "id": 12, "poet": "Javed Akhtar", "type": "shayari", "text": "Panchhi nadiya pawan ke jhonke\nKoi sarhad na inhein roke" },
  { "id": 13, "poet": "Bashir Badr", "type": "shayari", "text": "Koi hath bhi na milayega jo gale miloge tapak se\nYe naye mizaaj ka sheher hai zara fasle se mila karo" },
  { "id": 14, "poet": "Kaifi Azmi", "type": "shayari", "text": "Pyar ka jashn nayi tarah manana hoga\nGhum kisi dil mein sahi ghum ko mitana hoga" },
  { "id": 15, "poet": "Parveen Shakir", "type": "shayari", "text": "Wo toh khushboo hai hawaon mein bikhar jayega\nMasla phool ka hai phool kidhar jayega" },
  { "id": 16, "poet": "Majrooh Sultanpuri", "type": "shayari", "text": "Main akela hi chala tha jaanib-e-manzil magar\nLog saath aate gaye aur karwan banta gaya" },
  { "id": 17, "poet": "Daagh Dehlvi", "type": "shayari", "text": "Urdu hai jiska naam humein jaante hain 'Daagh'\nSari duniya mein dhoom hamari zuban ki hai" },
  { "id": 18, "poet": "Bahadur Shah Zafar", "type": "ghazal", "text": "Na kisi ki aankh ka noor hoon na kisi ke dil ka qarar hoon\nJo kisi ke kaam na aa sake main wo ek musht-e-ghubar hoon" },
  { "id": 19, "poet": "Momin Khan Momin", "type": "shayari", "text": "Tum mere paas hote ho goya\nJab koi doosra nahi hota" },
  { "id": 20, "poet": "Firaq Gorakhpuri", "type": "shayari", "text": "Sar-zameen-e-Hind par aqwam-e-alam ke 'Firaq'\nKarwan baste gaye Hindustan banta gaya" },
  { "id": 21, "poet": "Amrita Pritam", "type": "shayari", "text": "Main tainu pher milangi\nKitthe? Kis tarah? Pata nahi" },
  { "id": 22, "poet": "Dushyant Kumar", "type": "shayari", "text": "Ho gayi hai peer parvat si pighalni chahiye\nIs Himalaya se koi Ganga nikalni chahiye" },
  { "id": 23, "poet": "Shakeel Badayuni", "type": "shayari", "text": "Mere hum-nafas mere hum-nawa mujhe dost ban ke daga na de\nMain gham-e-jahan se bhara hua mera dil dukhane ki dua na de" },
  { "id": 24, "poet": "Nasir Kazmi", "type": "ghazal", "text": "Dil mein ek leher si uthi hai abhi\nKoi taza hawa chali hai abhi" },
  { "id": 25, "poet": "Qateel Shifai", "type": "shayari", "text": "Tumhare khat mein naya ek salam kiska tha\nNa tha raqeeb toh aakhir wo naam kiska tha" },
  { "id": 26, "poet": "Hasrat Mohani", "type": "ghazal", "text": "Chupke chupke raat din aansu bahana yaad hai\nHumein ab tak aashiqui ka wo zamana yaad hai" },
  { "id": 27, "poet": "Jigar Moradabadi", "type": "shayari", "text": "Ye ishq nahi aasan itna hi samajh lijiye\nEk aag ka darya hai aur doob ke jana hai" },
  { "id": 28, "poet": "Josh Malihabadi", "type": "shayari", "text": "Mera qalam toh amanat hai mere sheher ki\nMera qalam toh adalat hai mere sheher ki" },
  { "id": 29, "poet": "Saghar Siddiqui", "type": "shayari", "text": "Charagh-e-toor jalao bada andhera hai\nZara naqaab uthao bada andhera hai" },
  { "id": 30, "poet": "Waseem Barelvi", "type": "shayari", "text": "Apne chehre se jo zahir hai chupayein kaise\nTeri marzi ke mutabiq nazar aayein kaise" },
  { "id": 31, "poet": "Naseer Turabi", "type": "ghazal", "text": "Wo hum-safar tha magar us se hum-nawai na thi\nKi dhoop chaon ka aalam raha judai na thi" },
  {
    "id": 53,
    "text": "Khilkhilahat mein hai usk bachpan si baat,\nNakhre uske jaise phoolon ki saugaat.\nDil ke sheeshe mein tasveer bas jaaye,\nWoh masoom pari, jo khud ishq ban jaaye...",
    "poet": "Kunal",
    "type": "shayari"
  },
  {
    "id": 54,
    "text": "Badi fursat se khud ko tabaah kiya hai maine,\nAe dil, ye kis shakhs ki aadat laga li hai maine?\nWo mera nahi hai, par kisi aur ka ho... ye bardasht nahi,\nYe kis azaab mein apni zindagi fasa li hai maine?\nNa usey paane ki tamanna, aur usey khone ka darr,\nBas ek la-ilaj be-chaini se dosti kar li hai maine.....",
    "poet": "Kunal",
    "type": "shayari"
  },
  {
    "id": 55,
    "text": "Pata nahi kab yrr but I've fallen in love,\nUske liye maine kitni hi habits change ki hain,\nHasna, rona, depression, sab sikha hai,\nEk msg ke liye tarasna aur rona jana hai,\nEk msg se khushi aur sukun jana hai,\nJo kisi ko bataya nahi wo tujhe batake dil pashtaya hai,\nYe dil tu mujhe kaha le aya hai....",
    "poet": "Kunal",
    "type": "shayari"
  },
  {
    "id": 56,
    "text": "Sochta hu krdu use msg aur krte bethu baat koi,\nWo has de baato par essa hona bhi jaruri nahi,\nSochu use hi, bas sochta rahu jaise wo hai khawab mera koi,\nWo mera ho jaye aakhir me sirf mera,\nEssa hona bhi jaruri nahi......",
    "poet": "Kunal",
    "type": "shayari"
  },
  {
    "id": 57,
    "text": "Me usse yaad kr raha hu par saath koi tasvir nahi,\nWo hai mere qareeb par uske saath aaj kal koi baat nahi,\nMamla yeh bhi nahi ki raaz faash ho gaya,\nYaar ab har roz baat ho yeh taqdeer ki meherbani bhi toh nahi,\nLikhe honge hum saath kisi aur kaaynaat mein,\nPar sacch mano… iss duniya mein humara wujood\nkisi afsaaney se kam nahi…",
    "poet": "Kunal",
    "type": "shayari"
  },
  {
    "id": 58,
    "text": "Wo apane dosto ke saath sidiyo se utar rahi thi,\nMano seedha mere dil me utar rahi thi,\nUski wo chamakti aankho ka kya kehena,\nUnme to mujhe meri poori duniya nazar aa rahi thi......",
    "poet": "Kunal",
    "type": "shayari"
  }
];